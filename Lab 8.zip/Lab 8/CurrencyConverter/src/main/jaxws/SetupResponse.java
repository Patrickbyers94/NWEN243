
package main.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "setupResponse", namespace = "http://main/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "setupResponse", namespace = "http://main/")
public class SetupResponse {


}
